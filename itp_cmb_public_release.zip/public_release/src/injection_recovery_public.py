# ============================================================
# PUBLIC RELEASE SCRIPT
# Project: ITP CMB Memory Kernel
# Author: Stephen Atalebe
# Description:
#   Inject best-fit spline kernel into simulated κ-data and test recovery.
#
#   Steps:
#     1. Load best-fit spline kernel M_spline(u) and Commander κ-data.
#     2. Define a "true" κ_true(u_data) from the spline fit.
#     3. Generate N_inj noisy κ_sim = κ_true + noise.
#     4. For each κ_sim, run the spline fit and compute:
#          - recovered M_rec(u)
#          - D_rec, |lambda_back|_rec
#     5. Compare recovered quantities to the injected ones and
#        save summary + arrays for plotting (Figure 4).
# ============================================================

import numpy as np
from pathlib import Path

from config_public import PROJECT_ROOT, RESULTS_DIR
from fit_kernels_public import (
    load_kappa,
    ell_to_u,
    fit_spline,
    effective_D_and_lambda,
)


def main():
    print("=== ITP CMB Memory Kernel: injection_recovery_public ===")
    print(f"Project root: {PROJECT_ROOT}")
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    # --------------------------------------------------------
    # 1. Load Commander data and best-fit spline kernel
    # --------------------------------------------------------
    ell_data, kappa_data = load_kappa()
    u_data = ell_to_u(ell_data)

    print(f"[inj] Data ell={ell_data}, kappa={kappa_data}")
    print(f"[inj] u-data={u_data}")

    spline_path = RESULTS_DIR / "memory_kernel_spline_public.npz"
    if not spline_path.exists():
        raise FileNotFoundError(
            f"Spline kernel file not found at {spline_path}. "
            "Run fit_kernels_public.py first."
        )

    spline_arr = np.load(spline_path)
    u_grid_true = spline_arr["u"]
    M_true_grid = spline_arr["M"]

    print(f"[inj] Loaded best-fit spline kernel from {spline_path}")
    print(f"[inj] u-grid_true length = {len(u_grid_true)}")

    # Interpolate true kernel onto the data u-grid
    M_true_data = np.interp(u_data, u_grid_true, M_true_grid)

    # Define "true" κ on the data grid: use the spline fit as the noiseless signal
    # In the public code, the spline fit reproduces κ_data extremely well (χ² ~ 0),
    # so we can take κ_true(u_data) = κ_spline(u_data) ≈ κ_data.
    kappa_true = M_true_data.copy()

    # Same sigma as in fit_kernels_public
    sigma = np.full_like(kappa_data, 0.1)

    # Compute D_true and |lambda_back|_true from the true kernel
    D_true, lambda_true = effective_D_and_lambda(u_grid_true, M_true_grid)
    print(f"[inj] True D = {D_true:.4f}, |lambda_back| = {lambda_true:.4f}")

    # --------------------------------------------------------
    # 2. Set up injection-recovery experiment
    # --------------------------------------------------------
    N_inj = 100  # number of injections; can be increased if desired
    rng = np.random.default_rng(seed=54321)

    # Storage for summary statistics
    D_rec = np.zeros(N_inj, dtype=float)
    lambda_rec = np.zeros(N_inj, dtype=float)
    max_abs_err = np.zeros(N_inj, dtype=float)
    rms_err = np.zeros(N_inj, dtype=float)

    # For kernel shape comparison, evaluate both true and recovered
    # kernels on a common fine u-grid.
    u_grid = np.linspace(0.0, 1.0, 200)
    M_true_fine = np.interp(u_grid, u_grid_true, M_true_grid)

    print(f"[inj] Running {N_inj} injection–recovery realizations...")

    for i in range(N_inj):
        # ----------------------------------------------------
        # 2.1 Generate noisy κ_sim
        # ----------------------------------------------------
        noise = rng.normal(loc=0.0, scale=sigma[0], size=len(kappa_data))
        kappa_sim = kappa_true + noise

        # ----------------------------------------------------
        # 2.2 Recover kernel with the same spline fit used on data
        # ----------------------------------------------------
        spline_rec = fit_spline(u_data, kappa_sim)
        M_rec_fine = spline_rec(u_grid)

        # ----------------------------------------------------
        # 2.3 Compare M_rec to M_true and compute D, lambda
        # ----------------------------------------------------
        D_i, lambda_i = effective_D_and_lambda(u_grid, M_rec_fine)

        # Errors in kernel space
        diff = M_rec_fine - M_true_fine
        max_abs_err[i] = float(np.max(np.abs(diff)))
        rms_err[i] = float(np.sqrt(np.mean(diff**2)))

        D_rec[i] = D_i
        lambda_rec[i] = lambda_i

        if (i + 1) % 10 == 0:
            print(
                f"[inj] Realization {i+1}/{N_inj}: "
                f"D_rec={D_i:.4f}, |lambda_back|_rec={lambda_i:.4f}, "
                f"max|ΔM|={max_abs_err[i]:.4f}, rms|ΔM|={rms_err[i]:.4f}"
            )

    # --------------------------------------------------------
    # 3. Summarize results
    # --------------------------------------------------------
    D_mean = float(np.mean(D_rec))
    D_std = float(np.std(D_rec))
    lambda_mean = float(np.mean(lambda_rec))
    lambda_std = float(np.std(lambda_rec))
    max_abs_err_mean = float(np.mean(max_abs_err))
    max_abs_err_std = float(np.std(max_abs_err))
    rms_err_mean = float(np.mean(rms_err))
    rms_err_std = float(np.std(rms_err))

    print("\n[inj] Injection–recovery summary:")
    print(f"[inj] True D = {D_true:.4f}")
    print(f"[inj] Recovered D: mean={D_mean:.4f} ± {D_std:.4f}")
    print(f"[inj] True |lambda_back| = {lambda_true:.4f}")
    print(f"[inj] Recovered |lambda_back|: mean={lambda_mean:.4f} ± {lambda_std:.4f}")
    print(
        f"[inj] max|ΔM|: mean={max_abs_err_mean:.4f} ± {max_abs_err_std:.4f}, "
        f"rms|ΔM|: mean={rms_err_mean:.4f} ± {rms_err_std:.4f}"
    )

    # --------------------------------------------------------
    # 4. Save arrays and summary for plotting / Figure 4
    # --------------------------------------------------------
    np.savez(
        RESULTS_DIR / "injection_recovery_public.npz",
        u_grid=u_grid,
        M_true_fine=M_true_fine,
        D_true=D_true,
        lambda_true=lambda_true,
        D_rec=D_rec,
        lambda_rec=lambda_rec,
        max_abs_err=max_abs_err,
        rms_err=rms_err,
        N_inj=N_inj,
    )

    summary_path = RESULTS_DIR / "injection_recovery_summary_public.txt"
    with summary_path.open("w") as f:
        f.write("# Injection–recovery summary\n")
        f.write(f"N_inj = {N_inj}\n")
        f.write(f"D_true = {D_true:.6f}\n")
        f.write(f"lambda_true = {lambda_true:.6f}\n")
        f.write(f"D_mean = {D_mean:.6f}\n")
        f.write(f"D_std = {D_std:.6f}\n")
        f.write(f"lambda_mean = {lambda_mean:.6f}\n")
        f.write(f"lambda_std = {lambda_std:.6f}\n")
        f.write(f"max_abs_err_mean = {max_abs_err_mean:.6f}\n")
        f.write(f"max_abs_err_std = {max_abs_err_std:.6f}\n")
        f.write(f"rms_err_mean = {rms_err_mean:.6f}\n")
        f.write(f"rms_err_std = {rms_err_std:.6f}\n")

    print(f"[inj] Saved injection–recovery arrays and summary to {RESULTS_DIR}")
    print("[inj] Done.")


if __name__ == "__main__":
    main()
