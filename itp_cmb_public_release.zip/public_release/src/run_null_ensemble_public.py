# ============================================================
# PUBLIC RELEASE SCRIPT
# Project: ITP CMB Memory Kernel
# Author: Stephen Atalebe
# Description:
#   Null ensemble of ΛCDM-like skies, kernel fits, and Δχ² histogram.
#
#   For each Gaussian null realization of κ (with zero mean and the
#   same noise level as the Commander low-ℓ data), we:
#     1. Fit the exponential, polynomial, and spline kernels.
#     2. Compute χ²_null for the no-memory model (κ ≈ 0).
#     3. Compute χ²_best = min(χ²_exp, χ²_poly, χ²_spline).
#     4. Store Δχ² = χ²_null - χ²_best.
#
#   We then compare the Commander Δχ²_data to the simulated distribution
#   to obtain a look-elsewhere-corrected p-value.
# ============================================================

import numpy as np
from pathlib import Path

from config_public import PROJECT_ROOT, RESULTS_DIR
from fit_kernels_public import (
    load_kappa,
    ell_to_u,
    kernel_exp,
    kernel_poly,
    fit_exp,
    fit_poly,
    fit_spline,
)


def compute_chi2(kappa, kappa_model, sigma):
    """Simple χ² with constant errors."""
    return float(np.sum(((kappa - kappa_model) / sigma) ** 2))


def fit_all_kernels(u_data, kappa, sigma, u_grid):
    """
    Fit exponential, polynomial, and spline kernels to a given kappa(u).
    Returns:
      chi2_exp, chi2_poly, chi2_spline
    """
    # Exponential
    popt_exp, _ = fit_exp(u_data, kappa)
    kappa_exp_fit = kernel_exp(u_data, *popt_exp)
    chi2_exp = compute_chi2(kappa, kappa_exp_fit, sigma)

    # Polynomial
    popt_poly, _ = fit_poly(u_data, kappa)
    kappa_poly_fit = kernel_poly(u_data, *popt_poly)
    chi2_poly = compute_chi2(kappa, kappa_poly_fit, sigma)

    # Spline
    spline = fit_spline(u_data, kappa)
    kappa_spline_fit = spline(u_data)
    chi2_spline = compute_chi2(kappa, kappa_spline_fit, sigma)

    return chi2_exp, chi2_poly, chi2_spline


def main():
    print("=== ITP CMB Memory Kernel: run_null_ensemble_public ===")
    print(f"Project root: {PROJECT_ROOT}")
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    # -------------------------
    # Load real Commander kappa
    # -------------------------
    ell_data, kappa_data = load_kappa()
    u_data = ell_to_u(ell_data)

    print(f"[null] Data ell={ell_data}, kappa={kappa_data}")
    print(f"[null] u-data={u_data}")

    # Same constant sigma as in fit_kernels_public
    sigma = np.full_like(kappa_data, 0.1)

    # No-memory null model: κ_null ≈ 0
    kappa_null = np.zeros_like(kappa_data)

    # -------------------------
    # Commander Δχ²_data
    # -------------------------
    chi2_null_data = compute_chi2(kappa_data, kappa_null, sigma)
    chi2_exp_data, chi2_poly_data, chi2_spline_data = fit_all_kernels(
        u_data, kappa_data, sigma, u_grid=None
    )
    chi2_best_data = min(chi2_exp_data, chi2_poly_data, chi2_spline_data)
    delta_chi2_data = chi2_null_data - chi2_best_data

    print(f"[null] Data χ²_null = {chi2_null_data:.3f}")
    print(
        f"[null] Data χ²_exp={chi2_exp_data:.3f}, "
        f"χ²_poly={chi2_poly_data:.3f}, "
        f"χ²_spline={chi2_spline_data:.3f}"
    )
    print(f"[null] Data χ²_best = {chi2_best_data:.3f}")
    print(f"[null] Data Δχ²_data = {delta_chi2_data:.3f}")

    # -------------------------
    # Null ensemble simulations
    # -------------------------
    N_sims = 10000  # can be reduced for quick tests
    rng = np.random.default_rng(seed=12345)

    delta_chi2_sims = np.zeros(N_sims, dtype=float)
    chi2_null_sims = np.zeros(N_sims, dtype=float)
    chi2_best_sims = np.zeros(N_sims, dtype=float)

    print(f"[null] Running {N_sims} null simulations...")

    for i in range(N_sims):
        # Gaussian null: κ_sim ~ N(0, sigma^2)
        kappa_sim = rng.normal(loc=0.0, scale=sigma[0], size=len(kappa_data))

        chi2_null_i = compute_chi2(kappa_sim, kappa_null, sigma)
        chi2_exp_i, chi2_poly_i, chi2_spline_i = fit_all_kernels(
            u_data, kappa_sim, sigma, u_grid=None
        )
        chi2_best_i = min(chi2_exp_i, chi2_poly_i, chi2_spline_i)

        chi2_null_sims[i] = chi2_null_i
        chi2_best_sims[i] = chi2_best_i
        delta_chi2_sims[i] = chi2_null_i - chi2_best_i

        if (i + 1) % 1000 == 0:
            print(
                f"[null] Sim {i+1}/{N_sims}: "
                f"χ²_null={chi2_null_i:.2f}, χ²_best={chi2_best_i:.2f}, "
                f"Δχ²={delta_chi2_sims[i]:.2f}"
            )

    # -------------------------
    # Compute p-value
    # -------------------------
    # Look-elsewhere-corrected: we already took the min χ² over families
    # in each simulation and in the data.
    num_ge = np.sum(delta_chi2_sims >= delta_chi2_data)
    p_value = num_ge / N_sims

    print(f"[null] Δχ²_data = {delta_chi2_data:.3f}")
    print(
        f"[null] Fraction of sims with Δχ² >= Δχ²_data: "
        f"{num_ge}/{N_sims} → p = {p_value:.4f}"
    )

    # -------------------------
    # Save results
    # -------------------------
    np.savez(
        RESULTS_DIR / "null_ensemble_delta_chi2_public.npz",
        delta_chi2_sims=delta_chi2_sims,
        chi2_null_sims=chi2_null_sims,
        chi2_best_sims=chi2_best_sims,
        delta_chi2_data=delta_chi2_data,
        chi2_null_data=chi2_null_data,
        chi2_best_data=chi2_best_data,
        N_sims=N_sims,
    )

    summary_path = RESULTS_DIR / "null_ensemble_summary_public.txt"
    with summary_path.open("w") as f:
        f.write("# Null ensemble Δχ² summary\n")
        f.write(f"N_sims = {N_sims}\n")
        f.write(f"delta_chi2_data = {delta_chi2_data:.6f}\n")
        f.write(f"p_value = {p_value:.6f}\n")
        f.write(f"num_ge = {num_ge}\n")

    print(f"[null] Saved Δχ² array and summary to {RESULTS_DIR}")
    print("[null] Done.")


if __name__ == "__main__":
    main()
