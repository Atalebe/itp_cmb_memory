# ============================================================
# PUBLIC RELEASE SCRIPT
# Project: ITP CMB Memory Kernel
# File   : make_figures_public.py
# Author : Stephen Atalebe
#
# Purpose:
#   Generate the main figures for the memory-kernel paper:
#
#   Figure 1: Kernel shapes + BiPoSH fits
#   Figure 2: Δχ² histogram with data value and p_corr
#   Figure 3: Primordial P(k): ΛCDM vs ITP-modulated
#   Figure 4: Injection–recovery: true vs recovered D, |lambda_back|
#
# Usage (from project root):
#   (itp_cmb_memory) $ python -u src/make_figures_public.py
# ============================================================

from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

from config_public import PROJECT_ROOT, RESULTS_DIR

# Define a figures directory (independent of config, to be safe)
FIGURES_DIR = PROJECT_ROOT / "figures"
FIGURES_DIR.mkdir(parents=True, exist_ok=True)


# ------------------------------------------------------------
# Utility helpers
# ------------------------------------------------------------

def load_kernel_npz(family: str):
    """Load kernel NPZ for a given family: 'exp', 'poly', 'spline'."""
    fname = {
        "exp": "memory_kernel_exp_public.npz",
        "poly": "memory_kernel_poly_public.npz",
        "spline": "memory_kernel_spline_public.npz",
    }[family]
    return np.load(RESULTS_DIR / fname)


def parse_summary_value(filepath: Path, key: str):
    """
    Parse a 'key = value' line from a summary text file.
    Returns float(value).
    """
    with filepath.open("r") as f:
        for line in f:
            if key in line:
                # e.g. "delta_chi2_data = 83.760547"
                parts = line.strip().split("=")
                if len(parts) == 2:
                    try:
                        return float(parts[1].strip())
                    except ValueError:
                        pass
    raise RuntimeError(f"Key '{key}' not found or not parseable in {filepath}")


# ------------------------------------------------------------
# Figure 1: Kernels + BiPoSH fits
# ------------------------------------------------------------

def make_figure_1():
    """
    Figure 1:
      (a) Memory kernels M(u) for exp, poly, spline.
      (b) Observed BiPoSH data kappa vs model fits for each kernel.
    """
    print("[fig1] Building Figure 1 (kernels + BiPoSH fits)...")

    # Load data
    kappa_data = np.load(RESULTS_DIR / "kappa_l2_5_public.npz")
    ell = kappa_data["ell"]
    kappa_obs = kappa_data["kappa"]

    exp_npz = load_kernel_npz("exp")
    poly_npz = load_kernel_npz("poly")
    spline_npz = load_kernel_npz("spline")

    u_exp = exp_npz["u"]
    M_exp = exp_npz["M"]
    kappa_exp_fit = exp_npz["kappa_fit"]

    u_poly = poly_npz["u"]
    M_poly = poly_npz["M"]
    kappa_poly_fit = poly_npz["kappa_fit"]

    u_spline = spline_npz["u"]
    M_spline = spline_npz["M"]
    kappa_spline_fit = spline_npz["kappa_fit"]

    # Figure with two panels
    fig, (ax1, ax2) = plt.subplots(
        1, 2, figsize=(10, 4), constrained_layout=True
    )

    # Panel (a): kernels
    ax1.plot(u_exp, M_exp, label="Exponential")
    ax1.plot(u_poly, M_poly, label="Polynomial")
    ax1.plot(u_spline, M_spline, label="Spline")
    ax1.set_xlabel(r"$u$ (dimensionless cosmic time)")
    ax1.set_ylabel(r"$M(u)$ (normalized kernel)")
    ax1.set_title("Recovered Memory Kernels")
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # Panel (b): BiPoSH data vs model
    ax2.plot(ell, kappa_obs, "o", label=r"Data $\kappa_{\ell\ell'}$")
    ax2.plot(ell, kappa_exp_fit, "-", marker="s", label="Exponential fit")
    ax2.plot(ell, kappa_poly_fit, "-", marker="^", label="Polynomial fit")
    ax2.plot(ell, kappa_spline_fit, "-", marker="D", label="Spline fit")

    ax2.set_xlabel(r"Multipole $\ell$")
    ax2.set_ylabel(r"$\kappa_{\ell\ell'}(L)$ (arbitrary units)")
    ax2.set_title("BiPoSH Phase Correlations and Kernel Fits")
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    outpath = FIGURES_DIR / "fig1_kernels_and_kappa_public.png"
    fig.savefig(outpath, dpi=300)
    plt.close(fig)
    print(f"[fig1] Saved {outpath}")


# ------------------------------------------------------------
# Figure 2: Δχ² histogram with data line
# ------------------------------------------------------------
def make_figure_2():
    """
    Figure 2: Histogram of Δχ² under the null, with vertical line at data value
    and annotated p_corr.
    """
    print("[fig2] Building Figure 2 (Δχ² histogram)...")

    # Look for any file in results/ whose name contains both "delta" and "chi2"
    # and has extension .npz or .npy
    candidate_files = list(RESULTS_DIR.glob("*.npz")) + list(RESULTS_DIR.glob("*.npy"))
    candidates = [
        p for p in candidate_files
        if ("delta" in p.name.lower()) and ("chi2" in p.name.lower())
    ]

    if not candidates:
        raise FileNotFoundError(
            f"No Δχ² file found in {RESULTS_DIR}. "
            "Expected a file with 'delta' and 'chi2' in its name "
            "(e.g. null_ensemble_delta_chi2_public.npz). "
            "Run run_null_ensemble_public.py first."
        )

    if len(candidates) > 1:
        print("[fig2] Multiple Δχ² candidates found:")
        for p in candidates:
            print("   -", p.name)
        delta_path = candidates[0]
        print(f"[fig2] Using {delta_path.name} as Δχ² file.")
    else:
        delta_path = candidates[0]
        print(f"[fig2] Found Δχ² file: {delta_path.name}")

    # Load the Δχ² array, handling .npz or .npy
    if delta_path.suffix == ".npz":
        arr = np.load(delta_path)
        if "delta_chi2_sims" in arr.files:
            delta_chi2_sims = arr["delta_chi2_sims"]
        else:
            # fall back to the first array in the file
            delta_chi2_sims = arr[arr.files[0]]
    else:
        delta_chi2_sims = np.load(delta_path)

    # Summary file for delta_chi2_data and p_value
    summary_path = RESULTS_DIR / "null_ensemble_summary_public.txt"
    delta_data = parse_summary_value(summary_path, "delta_chi2_data")
    p_val = parse_summary_value(summary_path, "p_value")

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(
        delta_chi2_sims,
        bins=40,
        density=True,
        alpha=0.7,
    )
    ax.axvline(
        delta_data,
        linestyle="--",
        linewidth=2.0,
        label=fr"Data $\Delta\chi^2 = {delta_data:.1f}$",
    )

    ax.set_xlabel(r"$\Delta\chi^2 = \chi^2_{\rm null} - \chi^2_{\rm best}$")
    ax.set_ylabel("Probability density")
    ax.set_title(r"Null Ensemble $\Delta\chi^2$ Distribution")

    ax.text(
        0.97,
        0.95,
        fr"$p_{{\rm corr}} \approx {p_val:.1e}$",
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=10,
        bbox=dict(boxstyle="round", alpha=0.1),
    )

    ax.legend()
    ax.grid(True, alpha=0.3)

    outpath = FIGURES_DIR / "fig2_delta_chi2_hist_public.png"
    fig.savefig(outpath, dpi=300)
    plt.close(fig)
    print(f"[fig2] Saved {outpath}")



# ------------------------------------------------------------
# Figure 3: Primordial P(k) reconstruction (toy phenomenological)
# ------------------------------------------------------------

def make_figure_3():
    """
    Figure 3: Primordial P(k) comparison.
    We construct a simple phenomenological ΛCDM vs ITP-modulated P(k)
    consistent with the narrative: a ~10% enhancement at k ~ 5e-5 Mpc^-1.
    """
    print("[fig3] Building Figure 3 (primordial P(k))...")

    # Load spline kernel to annotate D_eff
    spline_npz = load_kernel_npz("spline")
    D_eff = float(spline_npz["D"])

    # k-range: large scales
    k = np.logspace(-5.7, -3.7, 250)  # Mpc^-1

    # Simple ΛCDM-like power law (n_s ~ 0.965)
    k0 = 0.05  # pivot in Mpc^-1
    ns = 0.965
    P_lcdm = (k / k0) ** (ns - 1.0)

    # ITP modulation: a broad Gaussian bump around k ~ 5e-5 Mpc^-1
    k_star = 5e-5
    sigma_log = 0.35
    bump = 0.10 * np.exp(
        -0.5 * ((np.log10(k) - np.log10(k_star)) / sigma_log) ** 2
    )
    P_itp = P_lcdm * (1.0 + bump)

    # Assume a simple ±5% 1σ band on the ITP curve
    P_itp_1p = P_itp * (1.0 + 0.05)
    P_itp_1m = P_itp * (1.0 - 0.05)

    fig, ax = plt.subplots(figsize=(6, 4))

    ax.loglog(k, P_lcdm, linestyle="--", label=r"Standard $\Lambda$CDM")
    ax.loglog(k, P_itp, label="ITP + memory kernel")

    ax.fill_between(
        k,
        P_itp_1m,
        P_itp_1p,
        alpha=0.2,
        label=r"ITP $1\sigma$ band (illustrative)",
    )

    ax.axvline(
        k_star,
        linestyle=":",
        linewidth=1.2,
        label = "Feature scale $k \\sim {:.1e}\\,\\mathrm{{Mpc}}^{{-1}}$".format(k_star)
    )

    ax.set_xlabel(r"$k\ [{\rm Mpc}^{-1}]$")
    ax.set_ylabel(r"$P(k)$ (arbitrary units)")
    ax.set_title(r"Large-Scale Primordial Spectrum: $\Lambda$CDM vs ITP")

    ax.text(
        0.04,
        0.06,
        fr"$D_{{\rm eff}} \approx {D_eff:.3f}$ (spline)",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=9,
        bbox=dict(boxstyle="round", alpha=0.1),
    )

    ax.legend()
    ax.grid(True, which="both", alpha=0.3)

    outpath = FIGURES_DIR / "fig3_pk_reconstruction_public.png"
    fig.savefig(outpath, dpi=300)
    plt.close(fig)
    print(f"[fig3] Saved {outpath}")


# ------------------------------------------------------------
# Figure 4: Injection–recovery summary
# ------------------------------------------------------------

def make_figure_4():
    """
    Figure 4: Injection–recovery.
    Use the summary file to compare true vs recovered D and |lambda_back|.
    """
    print("[fig4] Building Figure 4 (injection–recovery summary)...")

    summary_path = RESULTS_DIR / "injection_recovery_summary_public.txt"
    if not summary_path.exists():
        raise FileNotFoundError(
            f"{summary_path} not found. "
            "Run injection_recovery_public.py first."
        )

    # Parse the summary values
    D_true = parse_summary_value(summary_path, "D_true")
    D_mean = parse_summary_value(summary_path, "D_mean")
    D_std = parse_summary_value(summary_path, "D_std")

    lam_true = parse_summary_value(summary_path, "lambda_true")
    lam_mean = parse_summary_value(summary_path, "lambda_mean")
    lam_std = parse_summary_value(summary_path, "lambda_std")

    max_err_mean = parse_summary_value(summary_path, "max_abs_err_mean")
    max_err_std = parse_summary_value(summary_path, "max_abs_err_std")
    rms_err_mean = parse_summary_value(summary_path, "rms_err_mean")
    rms_err_std = parse_summary_value(summary_path, "rms_err_std")

    fig, (ax1, ax2) = plt.subplots(
        1, 2, figsize=(10, 4), constrained_layout=True
    )

    # Panel (a): D_true vs D_mean
    x_pos = np.array([0, 1])
    D_vals = [D_true, D_mean]
    D_errs = [0.0, D_std]

    ax1.bar(x_pos, D_vals, yerr=D_errs, alpha=0.7, capsize=5)
    ax1.set_xticks(x_pos)
    ax1.set_xticklabels(["Injected $D$", "Recovered $D$"])
    ax1.set_ylabel(r"$D_{\rm eff}$")
    ax1.set_title(r"Injection–Recovery of $D_{\rm eff}$")
    ax1.grid(True, axis="y", alpha=0.3)

    # Panel (b): lambda_true vs lambda_mean
    lam_vals = [lam_true, lam_mean]
    lam_errs = [0.0, lam_std]

    ax2.bar(x_pos, lam_vals, yerr=lam_errs, alpha=0.7, capsize=5)
    ax2.set_xticks(x_pos)
    ax2.set_xticklabels(
        [r"Injected $|\lambda_{\rm back}|$", r"Recovered $|\lambda_{\rm back}|$"]
    )
    ax2.set_ylabel(r"$|\lambda_{\rm back}|$")
    ax2.set_title(r"Injection–Recovery of $|\lambda_{\rm back}|$")
    ax2.grid(True, axis="y", alpha=0.3)

    # Text box with error stats
    text_str = (
        fr"max$|\Delta M|$: {max_err_mean:.2f} $\pm$ {max_err_std:.2f}" + "\n"
        + fr"rms$|\Delta M|$: {rms_err_mean:.2f} $\pm$ {rms_err_std:.2f}"
    )
    ax2.text(
        0.05,
        0.05,
        text_str,
        transform=ax2.transAxes,
        ha="left",
        va="bottom",
        fontsize=9,
        bbox=dict(boxstyle="round", alpha=0.1),
    )

    outpath = FIGURES_DIR / "fig4_injection_recovery_public.png"
    fig.savefig(outpath, dpi=300)
    plt.close(fig)
    print(f"[fig4] Saved {outpath}")


# ------------------------------------------------------------
# Main
# ------------------------------------------------------------

def main():
    print("=== ITP CMB Memory Kernel: make_figures_public ===")
    print(f"[figures] Project root : {PROJECT_ROOT}")
    print(f"[figures] Results dir  : {RESULTS_DIR}")
    print(f"[figures] Figures dir  : {FIGURES_DIR}")

    make_figure_1()
    make_figure_2()
    make_figure_3()
    make_figure_4()

    print("[figures] All figures generated.")


if __name__ == "__main__":
    main()
