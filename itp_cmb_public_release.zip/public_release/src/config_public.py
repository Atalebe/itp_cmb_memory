from pathlib import Path

# Project root is the folder containing this file's parent directory
PROJECT_ROOT = Path(__file__).resolve().parent.parent

DATA_DIR    = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
FIG_DIR     = PROJECT_ROOT / "figures"

# Planck Commander PR4 map (user must provide)
PLANCK_PR4_MAP = DATA_DIR / "COM_CMB_IQU-commander_PR4_R3.00.fits"
