# ITP CMB Memory Kernel – Public Release

This repository contains all data and scripts required to reproduce the results from:

**Stephen Atalebe (2025)**  
*A Direct Reconstruction of the Primordial Universe from CMB Phase Correlations: Evidence for a Cosmological Memory Kernel*

## Contents

### 1. Data Files (`.npz` and `.txt`)
- `kappa_l2_5_public.npz` — Observed BiPoSH phase correlation vector  
- `memory_kernel_exp_public.npz` — Exponential kernel fit  
- `memory_kernel_poly_public.npz` — Polynomial kernel fit  
- `memory_kernel_spline_public.npz` — Spline kernel fit  
- `null_ensemble_delta_chi2_public.npz` — Δχ² distribution from 10,000 mocks  
- `injection_recovery_public.npz` — Kernel injection–recovery dataset  
- Summary logs:  
  - `kernel_fit_summary_public.txt`  
  - `null_ensemble_summary_public.txt`  
  - `injection_recovery_summary_public.txt`

### 2. Figures
- `fig1_kernels_and_kappa_public.png`
- `fig2_delta_chi2_hist_public.png`
- `fig3_pk_reconstruction_public.png`
- `fig4_injection_recovery_public.png`

### 3. Public Scripts
Located in `src/`:
- `fit_kernels_public.py`
- `run_null_ensemble_public.py`
- `injection_recovery_public.py`
- `make_figures_public.py`
- `config_public.py`

These scripts provide complete, transparent, reproducible reconstruction of:
1. κ(l) extraction  
2. Kernel fitting  
3. Null ensemble analysis  
4. Injection–recovery validation  
5. Figure generation  

## How to Run

